setwd("~/Dropbox/space.mix/SpaceMix")
require(devtools)
require(rmarkdown)

load_all()
document()
Sys.setenv(PATH=paste(Sys.getenv("PATH"),"/usr/texbin",sep=":"))

#check(build_args="--resave-data")
#build(path="~/Dropbox/space.mix/SpaceMix",args="--resave-data")
system("R CMD build --resave-data /Users/gburd/Dropbox/space.mix/SpaceMix")
install()

devtools::install_github("gbradburd/SpaceMix",build_vignettes=TRUE)
