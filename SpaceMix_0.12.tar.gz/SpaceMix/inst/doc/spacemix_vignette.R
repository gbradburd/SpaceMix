## ----allele.count.data---------------------------------------------------
# load the example dataset and look at its elements
require(SpaceMix)
data(spacemix.example.dataset)
str(spacemix.example.dataset)

# look at the attributes of the allele counts matrix
dim(spacemix.example.dataset$allele.counts)
class(spacemix.example.dataset$allele.counts)

# look at the first 10 loci
spacemix.example.dataset$allele.counts[1:30,1:10]
spacemix.example.dataset$sample.sizes[1:30,1:10]

## ----allele.freq.data----------------------------------------------------
# load the example dataset and look at its elements
data(spacemix.example.dataset)
str(spacemix.example.dataset)

# Now create an example allele frequency matrix by 
#	dividing the allele counts by the sample sizes
allele.frequency.matrix <- spacemix.example.dataset$allele.counts / spacemix.example.dataset$sample.sizes


## ----mean.sample.size.data-----------------------------------------------
# Example sample size data
# 10 samples
K <- 10
# 50 loci
L <- 50

# Randomly determine a matrix of sample sizes between 0 and 10
#	(corresponding to up to 5 diploids genotyped in each sample)
ex.sample.sizes <- matrix(sample(c(0:10),size=500,replace=TRUE),nrow=K,ncol=L)

# To calculate mean sample sizes,
#	first replace all missing data 
#	(entries with a 0) with NA values
tmp.sample.sizes <- ex.sample.sizes
tmp.sample.sizes[which(ex.sample.sizes == 0)] <- NA
mean.sample.sizes <- rowMeans(tmp.sample.sizes,na.rm=TRUE)

## ----sample.cov.data.pt1-------------------------------------------------
# The function takes as its arguments a matrix of allele frequencies 
# 	with _K_ rows (number of samples) and _L_ columns (number of loci) 
#	and a matrix of sample sizes of the same dimensions.
calculate.mean.sample.freq <- function(frequencies,sample.sizes){
	frequencies[is.na(frequencies)] <- 0
	weighted.sample.frequencies <- colSums(frequencies * sample.sizes)/colSums(sample.sizes)
	return(weighted.sample.frequencies)
}

# and a demonstration:
sample.sizes <- matrix(c(4,5,5,5,4,5,3,5,4,4,
						 13,0,11,12,13,14,13,12,15,14,
						 22,21,22,24,22,24,24,25,19,24,
						 33,33,32,0,34,30,31,34,30,32,
						 58,58,59,58,62,57,0,58,55,59),
						 nrow=5,ncol=10,byrow=TRUE)
frequencies <- matrix(c(0.000,0.600,0.800,0.000,0.500,0.200,0.667,0.600,0.750,0.750,
						0.538,NaN,0.545,0.500,0.615,0.643,0.692,0.667,0.733,0.214,
						0.409,0.476,0.545,0.542,0.409,0.542,0.708,0.560,0.474,0.583,
						0.485,0.545,0.469,NaN,0.529,0.567,0.484,0.647,0.400,0.344,
						0.483,0.621,0.424,0.569,0.532,0.368,NaN,0.534,0.491,0.492),
						nrow=5,ncol=10,byrow=TRUE)
# get the weighted mean frequencies at each locus
calculate.mean.sample.freq(frequencies,sample.sizes)

# compare to the unweighted mean frequencies
colMeans(frequencies,na.rm=TRUE)

# but also note that these functions would return 
#	the same value if the sample sizes were all the same
calculate.mean.sample.freq(frequencies[,1,drop=FALSE],matrix(1000,nrow=5,ncol=1))

## ----sample.cov.data.pt2-------------------------------------------------
# start with a vector of mean sample sizes across samples
#	(this is calculated from the sample.sizes matrix in
#	the example above using the following command:
#		rowSums(sample.sizes)/ncol(sample.sizes))
mean.sample.sizes <- c(4.4,11.7,22.7,28.9,52.4)

# now calculate the sample size-weighted mean
# 	which is quite similar to the sample size-weighted 
#	mean with the actual sample size data at that locus.

calculate.mean.sample.freq(frequencies[,1],matrix(mean.sample.sizes,nrow=5,ncol=1))


## ----sample.cov.data.pt3-------------------------------------------------
# First, define a normalizing function:
normalize.allele.freqs <- function(frequencies,sample.sizes){
	mean.freqs <- calculate.mean.sample.freq(frequencies,sample.sizes)
	mean.freqs.mat <- matrix(mean.freqs,
								nrow=nrow(frequencies),
								ncol=ncol(frequencies),
								byrow=TRUE)
	normalized.freqs <- frequencies/sqrt(mean.freqs.mat * (1-mean.freqs.mat))
	return(normalized.freqs)
}

# Now take it out for a spin:
normalize.allele.freqs(frequencies[,1,drop=FALSE],sample.sizes[,1,drop=FALSE])

# And we can apply this normalization step to a whole matrix 
#	of allele frequencies
normalized.allele.freqs <- normalize.allele.freqs(frequencies,sample.sizes)

# Or, alternatively, if we only have a vector of mean 
#	sample sizes, we can use
mean.sample.size.mat <- matrix(mean.sample.sizes,nrow=5,ncol=10)
normalized.allele.freqs <- normalize.allele.freqs(frequencies,
													sample.sizes=mean.sample.size.mat)


## ----sample.cov.data.pt4-------------------------------------------------
# Start with the normalized sample allele frequencies
#	and ensure that the number of rows of this matrix 
#	is equal to the number of samples in your dataset,
#	which, in this example, is 5.
nrow(normalized.allele.freqs) == 5

# Once we have ensured this, we can simply calculate 
#	the pairwise covariance
sample.cov <- cov(t(normalized.allele.freqs),use="pairwise.complete.obs")
sample.cov

## ----sample.cov.data.pt5-------------------------------------------------
# Calculate the sample covariance without protecting 
#	against missing data values
sample.cov <- cov(t(normalized.allele.freqs))
sample.cov


## ----geo.sampling, fig.width=7, fig.height=3.5---------------------------
# Simulating random sampling points of longitude and latitude
long <- runif(10,-180,180)
lat <- runif(10,-90,90)

# Format those sampling points into a matrix
geo.coords <- cbind(long,lat)

# Take a look at the coordinates to make sure 
# 	there are no errors
geo.coords
class(geo.coords)
require(maps)
map(mar=rep(0.1,4))
points(geo.coords,pch=19,col="red")
box(lwd=2)

## ----ex.SpaceMix.run.1, eval=FALSE---------------------------------------
#  # EXAMPLE 1
#  
#  # First, load data object
#  data(spacemix.example.dataset)
#  
#  # Data option: allele counts and sample sizes
#  # Fast Model option: estimating geogenetic locations
#  # Long Model option: estimating geogenetic locations and
#  #					 admixture source locations
#  # Spatial priors: default variance,
#  #					observed geographic sampling locations
#  run.spacemix.analysis(n.fast.reps = 10,
#  						fast.MCMC.ngen = 1e5,
#  						fast.model.option = "target",
#  						long.model.option = "source_and_target",
#  						data.type = "counts",
#  						sample.frequencies=NULL,
#  						mean.sample.sizes=NULL,
#  						counts = spacemix.example.dataset$allele.counts,
#  						sample.sizes = spacemix.example.dataset$sample.sizes,
#  						sample.covariance=NULL,
#  						target.spatial.prior.scale=NULL,
#  						source.spatial.prior.scale=NULL,
#  						spatial.prior.X.coordinates = spacemix.example.dataset$population.coordinates[,1],
#  						spatial.prior.Y.coordinates = spacemix.example.dataset$population.coordinates[,2],
#  						round.earth = FALSE,
#  						long.run.initial.parameters=NULL,
#  						k = nrow(spacemix.example.dataset$allele.counts),
#  						loci = ncol(spacemix.example.dataset$sample.sizes),
#  						ngen = 1e6,
#  						printfreq = 1e2,
#  						samplefreq = 1e3,
#  						mixing.diagn.freq = 50,
#  						savefreq = 1e5,
#  						directory=NULL,
#  						prefix = "example_run1")

## ----ex.SpaceMix.run.2, eval=FALSE---------------------------------------
#  # EXAMPLE 2
#  
#  # First, load data object
#  data(spacemix.example.dataset)
#  
#  # Next, make allele frequencies and mean sample size objects
#  allele.frequencies <- spacemix.example.dataset$allele.counts / spacemix.example.dataset$sample.sizes
#  tmp.sample.sizes <- spacemix.example.dataset$sample.sizes
#  tmp.sample.sizes[which(spacemix.example.dataset$sample.sizes == 0)] <- NA
#  mean.sample.sizes <- rowMeans(tmp.sample.sizes,na.rm=TRUE)
#  
#  # Data option: allele frequencies and mean sample sizes
#  # Fast Model option: estimating geogenetic locations and
#  #					 admixture source locations
#  # Long Model option: estimating geogenetic locations and
#  #					 admixture source locations
#  # Spatial priors: default variance,
#  #					random locations for sampling coordinates
#  run.spacemix.analysis(n.fast.reps = 10,
#  						fast.MCMC.ngen = 1e5,
#  						fast.model.option = "source_and_target",
#  						long.model.option = "source_and_target",
#  						data.type = "sample.frequencies",
#  						sample.frequencies = allele.frequencies,
#  						mean.sample.sizes = mean.sample.sizes,
#  						counts = NULL,
#  						sample.sizes = NULL,
#  						sample.covariance=NULL,
#  						target.spatial.prior.scale=NULL,
#  						source.spatial.prior.scale=NULL,
#  						spatial.prior.X.coordinates = runif(nrow(spacemix.example.dataset$allele.counts),-180,180),
#  						spatial.prior.Y.coordinates = runif(nrow(spacemix.example.dataset$allele.counts),-90,90),
#  						round.earth = TRUE,
#  						long.run.initial.parameters=NULL,
#  						k = nrow(allele.frequencies),
#  						loci = ncol(allele.frequencies),
#  						ngen = 1e6,
#  						printfreq = 1e2,
#  						samplefreq = 1e3,
#  						mixing.diagn.freq = 50,
#  						savefreq = 1e5,
#  						directory=NULL,
#  						prefix = "example_run2")

## ----ex.SpaceMix.run.3, eval=FALSE---------------------------------------
#  # EXAMPLE 3
#  
#  # First, load data object
#  data(spacemix.example.dataset)
#  
#  # Next, calculate sample covariance of normalized allele frequencies
#  allele.frequencies <- spacemix.example.dataset$allele.counts / spacemix.example.dataset$sample.sizes
#  normalized.allele.freqs <- normalize.allele.freqs(allele.frequencies,spacemix.example.dataset$sample.sizes)
#  sample.cov <- cov(t(normalized.allele.freqs))
#  
#  # And get the mean sample sizes
#  tmp.sample.sizes <- spacemix.example.dataset$sample.sizes
#  tmp.sample.sizes[which(spacemix.example.dataset$sample.sizes == 0)] <- NA
#  mean.sample.sizes <- rowMeans(tmp.sample.sizes,na.rm=TRUE)
#  
#  # Now, generate a list of parameter values at which to initiate
#  #	the analysis
#  initial.param.vals <- list("a0" = 0.9,
#  					 "a1" = 1.3,
#  					 "a2" = 0.5,
#  					 "population.coordinates" = rbind(spacemix.example.dataset$population.coordinates,
#  					 						   matrix(runif(60,1,9),nrow=30,ncol=2)),
#  					 "admix.proportions" = rep(0.01,30),
#  					 "nugget" = rep(0.1,30))
#  # Data option: sample normalized allele frequency covariance
#  #				and mean sample sizes
#  # Fast Model option: no fast runs
#  # Long Model option: estimating geogenetic locations and
#  #					 admixture source locations
#  # Specifying initial parameter values for the long run
#  # Spatial priors: default variance,
#  #					random locations for sampling coordinates
#  #
#  run.spacemix.analysis(n.fast.reps = 0,
#  						fast.MCMC.ngen = 0,
#  						fast.model.option = "source_and_target",
#  						long.model.option = "source_and_target",
#  						data.type = "sample.covariance",
#  						sample.frequencies = NULL,
#  						mean.sample.sizes = mean.sample.sizes,
#  						counts = NULL,
#  						sample.sizes = NULL,
#  						sample.covariance = sample.cov,
#  						target.spatial.prior.scale=NULL,
#  						source.spatial.prior.scale=NULL,
#  						spatial.prior.X.coordinates = runif(nrow(spacemix.example.dataset$allele.counts),-180,180),
#  						spatial.prior.Y.coordinates = runif(nrow(spacemix.example.dataset$allele.counts),-90,90),
#  						round.earth = TRUE,
#  						long.run.initial.parameters = initial.param.vals,
#  						k = nrow(sample.cov),
#  						loci = ncol(allele.frequencies),
#  						ngen = 1e6,
#  						printfreq = 1e2,
#  						samplefreq = 1e3,
#  						mixing.diagn.freq = 50,
#  						savefreq = 5e4,
#  						directory=NULL,
#  						prefix = "example_run3")

## ----trace.plots, fig.width=7, fig.height=3.5----------------------------
# First, load the example data object
data(ex.output)

# Trace plot of posterior probability over the MCMC
plot(ex.output$Prob,xlab="MCMC iterations",ylab="value",
	main="Posterior probability trace plot",type='l')

# Trace plots of alpha parameters of the spatial covariance function
matplot(t(ex.output$nugget),type='l',
			xlab="MCMC iterations",ylab="Parameter value",
			main="Trace plot of nugget parameters")

## ----joint.marginals, fig.width=5, fig.height=5, fig.align='center'------

# Joint marginal plot of a0 and a1
#	colored by where in the MCMC these 
#	parameters took their values
plot(ex.output$a0,ex.output$a1,xlab="a0",ylab="a1",
	main="Joint marginal of a0 and a1",pch=20,
	col=adjustcolor(rainbow(1000,start=4/6,end=6/6),0.3))
legend(x="bottomright",pch=19,cex=0.8,
		col=rainbow(1000,start=4/6,end=6/6)[c(1,500,1000)],
		legend=c("Sampled MCMC iteration 1",
				 "Sampled MCMC iteration 500",
				 "Sampled MCMC iteration 1000"))


## ----acceptance.rates, fig.width=7, fig.height=3.5-----------------------
# First, load the example data object
data(ex.output)

# Acceptance rate of a0 over the course of the 
#	MCMC analysis
plot(ex.output$accept_rates$a0_accept_rate,
		xlab="MCMC iterations",ylab="Acceptance rate",
		main="Acceptance rate of a0",type='l',
		ylim=c(0.35,0.6))
	abline(h=0.44,col="gray",lty=2)

# Acceptance rates of nugget parameters over the 
#	course of the MCMC analysis
matplot(t(ex.output$accept_rates$nugget_accept_rate),
			xlab="MCMC iterations",ylab="Acceptance rate",
			main="Acceptance rates of nuggets",type='l',
			ylim=c(0.3,0.7))
	abline(h=0.44,col="gray",lty=2)

## ----model.adequacy, fig.width=6, fig.height=5, fig.align='center'-------
# first, load the standardized (mean-centered and normalized)
#	allele frequency data object.  This object, which is the 
#   "MCN.frequencies.list" (Mean Centered and Normalized) is 
#	saved in the Long Run directory, and is generated if the 
#	user has specified either allele count or allele frequeny 
#	data. 
#	Note that it is not generated if the user has specified the 
#	sample covariance.

data(MCN.frequencies.list.RData)

# Now, calculate the sample covariance from the mean centered 
# 	and normalized sample allele frequencies.
	sample.covariance <- cov(t(MCN.frequencies.list$mean.centered.normalized.sample.frequencies),
								use="pairwise.complete.obs")

# Next, load the example SpaceMix output object
data(ex.output)

# Create a matrix that will perform a mean-centering 
#	on the parametric covariance matrix
# Then, mean-center the parametric ovariance matrix.
	k <- nrow(MCN.frequencies.list$mean.centered.normalized.sample.frequencies)
	MC.matrix <- diag(k) - matrix(1/ex.output$last.params$inv.mean.sample.sizes / 
									(sum(1/ex.output$last.params$inv.mean.sample.sizes)),
										nrow=k,ncol=k,byrow=TRUE)
								
	MC.parametric.covariance <- (MC.matrix) %*% 	
									ex.output$last.params$admixed.covariance %*% 
									t(MC.matrix)

# Finally, compare the sample covariance to the parametric
#	covariance.  Ideally, there will be a very tight correspondence 
#	between the data and the model.  If there is not, it may 
#	be an indication either that the MCMC has not converged on 
#	the stationary distribution or that the process that generated 
#	the data is only poorly approximated by SpaceMix's model.

# The sample and parametric covariances can be plotted 
#	against each other (if model fit is good they should 
#	fall on the x=y red line)
index.matrix <- upper.tri(sample.covariance,diag=TRUE)
plot(sample.covariance[index.matrix], 
	MC.parametric.covariance[index.matrix],
	col=adjustcolor("black",0.3),pch=20,
	xlab="Sample covariance",
	ylab="Parametric covariance",
	main="Model adequacy:\n matrix comparison")
	abline(0,1,col="red")

# Or the patterns of decay of covariance with 
#	geographic distance can be compared between 
#	the data and the model.
plot(ex.output$last.params$D[1:k,1:k][index.matrix], 
		sample.covariance[index.matrix],
		pch=19,col="black",
		xlab="geogenetic distance",
		ylab="covariance",
		main="Model adequacy:\n IBD patterns")
		points(ex.output$last.params$D[1:k,1:k][index.matrix], 
				MC.parametric.covariance[index.matrix],col="red",pch=20)
		legend(x="topright",pch=19,col=c(1,2),
				legend=c("observed","model estimate"))
				
# note, this can also be applied over the posterior distribution 
#	of parametric covariances, to visualize fit over the whole MCMC


## ----example.map.list, eval=FALSE----------------------------------------
#  # Say that we have 30 samples from a regular grid
#  population.coordinates <- matrix(c(1,1,1,1,1,3,3,3,3,3,5,5,5,5,5,
#  									7,7,7,7,7,9,9,9,9,9,11,11,11,11,11,
#  									1,3,5,7,9,1,3,5,7,9,1,3,5,7,9,
#  									1,3,5,7,9,1,3,5,7,9,1,3,5,7,9),
#  								nrow=30,ncol=2)
#  # Now generate a vector of sample names
#  sample.names <- unlist(lapply(1:30,function(i){sprintf("Sample_%s",i)}))
#  
#  # And generate a vector of sample colors
#  rainbow(n=30,start=4/6,end=6/6)[as.numeric(cut(population.coordinates[,1],30))]
#  
#  # And now generate a sample map list using a 95%
#  #	credible interval on parameter estimates without
#  # 	`burning' (i.e., discarding) any sampled iterations
#  #	of the MCMC.
#  example.spacemix.map.list <- make.spacemix.map.list(MCMC.output.file = "~/MY_PATH/example_MCMC_output1.Robj",
#  								geographic.locations = population.coordinates,
#  								name.vector = sample.names,
#  								color.vector = sample.colors,
#  								quantile=0.95,
#  								burnin=0)

## ----geogenetic.maps, fig.width=7, fig.height=6, fig.align='center'------
# load the example map list generated using the code 
#	block above (with a real path for the output object
data(example.spacemix.map.list)

# Now we generate a map of the output showing sample names 
#	at the locations of the maximum a posteriori (MAP) 
#	geogenetic location parameter estimates
make.spacemix.map(spacemix.map.list = example.spacemix.map.list,
				text=TRUE,
				ellipses=FALSE,
				source.option=FALSE)

# Now, to visualize uncertainty in location parameter estimates, 
#	we generate a map of the output showing 95% credible
#	ellipses for the geogenetic locations of all samples 
#	and plotting sample names at the locations of the 
#	maximum a posteriori (MAP) geogenetic location parameter
#	estimates
make.spacemix.map(spacemix.map.list = example.spacemix.map.list,
				text=TRUE,
				ellipses=TRUE,
				source.option=FALSE)

# Notice that the figure is cut off a little bit, 
#	so we can tweak that to make it nicer
make.spacemix.map(example.spacemix.map.list,
				source.option=TRUE,
				text=TRUE,xlim=c(0.5,12),ylim=c(0,10))

# Now, to visualize the sources of admixture, we can plot 
#	those as well
make.spacemix.map(example.spacemix.map.list,
				source.option=TRUE,
				text=TRUE,xlim=c(0.5,12),ylim=c(0,10))

# This map looks like a bit of a mess, because even though
#	most samples are drawing negligible amounts of admixture,
#	they're all drawing SOME admixture, so they all get plotted 
#	and the output is difficult to visually interpret.
#
# To do a better job, we can be selective about which admixutre 
#	sources we highlight using the `query.spacemix.map` function
make.spacemix.map(example.spacemix.map.list,
				source.option=FALSE,
				text=FALSE,xlim=c(0,13),ylim=c(-3,11))

# Now, we just highlight the geogenetic location for Sample 9, 
#	as well as the location of its source of admixture, which 
#	is plotted in italics with a dashed border around its 95% 
#	credible ellipse.
query.spacemix.map(focal.pops=c("Sample_9"),
						spacemix.map.list = example.spacemix.map.list,
						ellipses=TRUE,source.option=TRUE)

