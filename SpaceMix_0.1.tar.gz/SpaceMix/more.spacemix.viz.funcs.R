################################################################
################################################################
#	SpaceMix plotting functions
################################################################
################################################################


################################
#	MCMC diagnosis
################################

################
#	Trace Plots
################
#	plot posterior probability trace plot
plot(Prob)

#	plot trace plots for parameters of 
#		spatial covariance function
par(mfrow=c(1,3))
	plot(a0)
	plot(a1)
	plot(a2)

#	plot trace plot for nugget parameters
#		(showing population specific drift)
matplot(t(nugget),type='l')

#	plot trace plot for admixture parameters
#		(showing population admixture proportions)
matplot(t(admix.proportions),type='l')

################
#	Acceptance Rate Plots
################

#	plot acceptance rates for parameters of 
#		spatial covariance function
par(mfrow=c(1,3))
	plot(accept_rates$a0_accept_rate)
	plot(accept_rates$a1_accept_rate)
	plot(accept_rates$a2_accept_rate)

#	plot trace plot for nugget parameters
#		(showing population specific drift)
matplot(t(accept_rates$nugget_accept_rate),type='l')

#	plot trace plot for admixture parameters
#		(showing population admixture proportions)
matplot(t(accept_rates$admix_proportions_accept_rate),type='l')


################################
#	Visualizing model output
################################

################
#	Evaluating model fit
################

#	plot fit of estimated parametric covariance matrix to 
#		sample covariance over the course of the MCMC
plot(last.params$sample.covariance,
		last.params$transformed.covariance,type='n',
		ylim=c(range(unlist(transformed.covariance.list))),
		xlim=c(range(last.params$sample.covariance)))
	abline(0,1,col="red")
	lapply(1:length(transformed.covariance.list),
			FUN=function(i){points(last.params$sample.covariance,
									transformed.covariance.list[[i]],
									pch = 20,
									col=adjustcolor(1,0.05));return()})

#	plot sample covariance against distance, and plot
#		parametric covariance against distance around that, 
#		to observe model fit

# first, load the standardized (mean-centered and normalized)
#	allele frequency data object
load(list.files(pattern="MCN.frequencies.list"))
	
	transformation.matrix <- diag(last.params$k) - 
								matrix(1/last.params$inv.mean.sample.sizes / 
									(sum(1/last.params$inv.mean.sample.sizes)),
										nrow=last.params$k,ncol=last.params$k,
								byrow=TRUE)
	
	sample.covariance <- cov(t(MCN.frequencies.list$mean.centered.normalized.sample.frequencies))
	mean.centered.parametric.covariance <- (transformation.matrix) %*% last.params$admixed.covariance %*% t(transformation.matrix)
	
	plot(last.params$D[1:last.params$k,1:last.params$k], sample.covariance,pch=19,col="red")
		points(last.params$D[1:last.params$k,1:last.params$k], mean.centered.parametric.covariance,col=1,pch=20)

# note, this can also be applied over the posterior distribution of parametric covariances, 
#	to visualize fit over the whole MCMC